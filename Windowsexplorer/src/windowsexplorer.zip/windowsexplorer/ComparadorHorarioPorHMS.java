package upm.aed.windowsexplorer;
import java.util.Comparator;

public class ComparadorHorarioPorHMS implements Comparator<Horario> {

	public ComparadorHorarioPorHMS() {
		
		
	}

	@Override
	public int compare(Horario o1, Horario o2) {
		// TODO Auto-generated method stub
		return 0;
	}

		
	
}
