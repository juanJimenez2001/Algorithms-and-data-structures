package upm.aed.windowsexplorer;

public interface Predicado<E> {

	public boolean test (E val);
}
