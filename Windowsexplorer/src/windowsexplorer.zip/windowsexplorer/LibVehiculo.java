package upm.aed.windowsexplorer;

public class LibVehiculo {

	// constantes p�blicas
	public final static int tierra = 1;
	public final static int mar = 2;
	public final static int aire = 3;
	
	
	// 1 Dada una lista de vehiculos determinar si 

}
